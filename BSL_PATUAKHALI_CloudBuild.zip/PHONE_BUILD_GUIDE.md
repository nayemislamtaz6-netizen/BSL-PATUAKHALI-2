# ফোন থেকে APK বানানোর সহজ পদ্ধতি

এই project-এ GitHub Actions cloud build workflow যোগ করা হয়েছে।

1. GitHub-এ একটি account খুলুন/লগইন করুন।
2. New repository তৈরি করুন, যেমন `BSL-PATUAKHALI`.
3. এই ZIP-এর ভেতরের সব file/folder repository-তে upload করুন।
4. `Actions` tab খুলুন।
5. `Build BSL PATUAKHALI APK` workflow নির্বাচন করুন।
6. `Run workflow` চাপুন।
7. Build শেষ হলে workflow-এর সফল run খুলুন।
8. `Artifacts` অংশে `BSL-PATUAKHALI-APK` চাপুন।
9. ZIP download করে ভেতরের `app-debug.apk` ফোনে install করুন।

এই cloud workflow APK build করে artifact হিসেবে দেয়। Android-এর Gradle build system APK তৈরি করে এবং debug APK default debug signing দিয়ে installable হয়.

গুরুত্বপূর্ণ:
- এই v1 এখনো local-data prototype; online multi-user/backend নেই।
- Production release-এর জন্য secure signing key এবং backend/Firebase প্রয়োজন।
- Public link দিয়ে সবাইকে install করাতে হলে APK-টি পরে একটি file-hosting service-এ upload করে share link দিতে হবে, অথবা Play Store/Firebase App Distribution ব্যবহার করতে হবে।
