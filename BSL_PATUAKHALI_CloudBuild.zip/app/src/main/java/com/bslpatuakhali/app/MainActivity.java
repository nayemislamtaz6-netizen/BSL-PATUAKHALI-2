package com.bslpatuakhali.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    ArrayList<Member> pending = new ArrayList<>();
    final int GREEN=Color.rgb(0,106,78), DARK=Color.rgb(0,77,57), RED=Color.rgb(244,42,65);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        showHome();
    }

    TextView tv(String s, float size, int color) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(8,8,8,8); return t;
    }
    Button btn(String s, int bg) {
        Button b=new Button(this); b.setText(s); b.setTextColor(Color.WHITE);
        b.setTextSize(14); b.setAllCaps(false);
        GradientDrawable g=new GradientDrawable(); g.setColor(bg); g.setCornerRadius(22); b.setBackground(g);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,56); p.setMargins(0,8,0,8); b.setLayoutParams(p);
        return b;
    }
    EditText input(String hint, boolean pass) {
        EditText e=new EditText(this); e.setHint(hint); e.setTextSize(16); e.setPadding(18,0,18,0);
        e.setSingleLine(true); if(pass) e.setInputType(0x81);
        GradientDrawable g=new GradientDrawable(); g.setColor(Color.WHITE); g.setStroke(1,Color.rgb(205,220,214)); g.setCornerRadius(18); e.setBackground(g);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,58); p.setMargins(0,6,0,8); e.setLayoutParams(p); return e;
    }
    void base(String title) {
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(20,20,20,20);
        GradientDrawable bg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{DARK,GREEN,DARK}); root.setBackground(bg);
        ScrollView sc=new ScrollView(this); content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        sc.addView(content); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
        TextView h=tv("🇧🇩  "+title,25,Color.WHITE); h.setTypeface(null,1); content.addView(h);
        TextView sub=tv("বাংলাদেশ • সদস্য ব্যবস্থাপনা",14,Color.WHITE); sub.setAlpha(.85f); content.addView(sub);
    }
    LinearLayout card() {
        LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(18,18,18,18);
        GradientDrawable g=new GradientDrawable(); g.setColor(Color.WHITE); g.setCornerRadius(28); c.setBackground(g);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,16,0,8); c.setLayoutParams(p); content.addView(c); return c;
    }
    void showHome() {
        base("BSL PATUAKHALI");
        LinearLayout c=card(); c.addView(tv("Membership & Designation",21,DARK));
        c.addView(tv("সদস্য হতে Registration করুন অথবা Admin Panel খুলুন।",14,Color.DKGRAY));
        Button r=btn("Member Registration",GREEN), a=btn("Admin Panel",RED); c.addView(r); c.addView(a);
        r.setOnClickListener(v->showRegister()); a.setOnClickListener(v->showAdmin());
    }
    void showRegister() {
        base("Member Registration"); LinearLayout c=card();
        EditText name=input("পূর্ণ নাম",false), phone=input("মোবাইল নম্বর",false), pass=input("পাসওয়ার্ড",true);
        c.addView(tv("নতুন সদস্য",20,DARK)); c.addView(name); c.addView(phone); c.addView(pass);
        Button b=btn("Register",GREEN); c.addView(b); TextView msg=tv("",14,Color.DKGRAY); c.addView(msg);
        b.setOnClickListener(v->{ if(name.getText().length()<2||phone.getText().length()<6||pass.getText().length()<6){msg.setText("সব তথ্য সঠিকভাবে দিন।");return;}
            pending.add(new Member(name.getText().toString(),phone.getText().toString())); msg.setText("Registration সফল। Admin approval-এর জন্য অপেক্ষমাণ।"); name.setText("");phone.setText("");pass.setText("");});
        Button back=btn("← Back",DARK); c.addView(back); back.setOnClickListener(v->showHome());
    }
    void showAdmin() {
        base("Admin Panel"); LinearLayout c=card(); c.addView(tv("Admin Login",20,DARK));
        EditText pin=input("Admin PIN",true); c.addView(pin); Button login=btn("Login",GREEN); c.addView(login);
        TextView msg=tv("Demo PIN: 1234",13,Color.GRAY); c.addView(msg);
        login.setOnClickListener(v->{if(pin.getText().toString().equals("1234")) showAdminDashboard(); else msg.setText("ভুল Admin PIN।");});
        Button back=btn("← Back",DARK); c.addView(back); back.setOnClickListener(v->showHome());
    }
    void showAdminDashboard() {
        base("Admin Dashboard"); LinearLayout c=card(); c.addView(tv("Pending Members",20,DARK));
        if(pending.isEmpty()) c.addView(tv("কোনো pending member নেই।",14,Color.GRAY));
        for(Member m: new ArrayList<>(pending)) {
            LinearLayout row=cardInner(); row.addView(tv(m.name,18,DARK)); row.addView(tv(m.phone,14,Color.GRAY));
            Spinner sp=new Spinner(this); String[] ds={"সদস্য","সভাপতি","সাধারণ সম্পাদক","সহ-সভাপতি","যুগ্ম সাধারণ সম্পাদক"}; ArrayAdapter<String> ad=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,ds); sp.setAdapter(ad); row.addView(sp);
            Button ap=btn("Approve & Assign",GREEN); row.addView(ap); c.addView(row);
            ap.setOnClickListener(v->{m.designation=(String)sp.getSelectedItem(); pending.remove(m); Toast.makeText(this,"Approved: "+m.designation,Toast.LENGTH_SHORT).show(); showAdminDashboard();});
        }
        Button refresh=btn("Refresh",RED); c.addView(refresh); refresh.setOnClickListener(v->showAdminDashboard());
    }
    LinearLayout cardInner(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);x.setPadding(12,12,12,12);GradientDrawable g=new GradientDrawable();g.setColor(Color.rgb(245,249,247));g.setCornerRadius(18);x.setBackground(g);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,8,0,8);x.setLayoutParams(p);return x;}
    static class Member {String name,phone,designation="Pending"; Member(String n,String p){name=n;phone=p;}}
}
