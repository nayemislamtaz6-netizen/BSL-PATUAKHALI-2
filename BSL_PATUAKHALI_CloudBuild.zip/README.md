# BSL PATUAKHALI — Android v1.0

This is the first installable Android Studio project.

Features:
- Bangladesh green/red visual theme
- Member registration
- Admin login (demo PIN: 1234)
- Pending member list
- Admin-only designation assignment
- Approve member flow

IMPORTANT:
This v1 stores data locally on the device. It is NOT yet an online multi-user production system.
For real use by many phones, Firebase/another secure backend must be connected for authentication, database, admin authorization and push notifications.

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The debug APK will be generated under app/build/outputs/apk/debug/.

Android Studio/Gradle are the standard Android build path.
